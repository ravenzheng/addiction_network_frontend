function AboutUsCtrl() {
  // todo
}
module.exports = {
  template: require('./view.html'),
  controller: AboutUsCtrl
};
