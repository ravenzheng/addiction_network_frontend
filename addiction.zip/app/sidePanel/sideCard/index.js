module.exports = {
  template: require('./view.html'),
  controller: require('./ctrl'),
  controllerAs: '$ctrl'
};
