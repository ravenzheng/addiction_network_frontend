// ratings :[{
//   "id": 3,
//   "star": 5,
//   "name": "Cat Woman",
//   "review": "Awesome"
// }]

module.exports = ctrl;

function ctrl() {
  // todo
}
