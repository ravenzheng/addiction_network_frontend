module.exports = ctrl;

function ctrl() {
  var vm = this;
  vm.interval = 3000;
  vm.noWrap = false;
}
