module.exports = [ctrl];

function ctrl() {
  var vm= this;
  vm.test=function(){
    console.log('testing');
  }
}
