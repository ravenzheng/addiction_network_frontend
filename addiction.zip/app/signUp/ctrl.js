module.exports = [ctrl];

function ctrl() {

}
