require('./style.css');

module.exports = {
  template: require('./view.html'),
  controller: require('./ctrl')
};
