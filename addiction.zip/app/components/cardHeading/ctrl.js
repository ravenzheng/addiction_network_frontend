module.exports = ctrl;

function ctrl() {
  // todo
}
