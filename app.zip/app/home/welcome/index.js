function WelcomeCtrl() {
  // todo
}

module.exports = {
  template: require('./view.html'),
  controller: WelcomeCtrl
};
